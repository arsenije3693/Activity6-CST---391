import AboutBox from "../components/AboutBox";

export const metadata = {
  title: "About – Music App",
};

export default function AboutPage() {
  return (
    <div>
      <AboutBox />
    </div>
  );
}
